package org.kahina.tulipa.bridge;

public class TulipaBridgeCommand
{
    public static final int DO_NOTHING = 0;
    public static final int CREEP = 1;
    public static final int FAIL = 2;
}
