package org.kahina.tulipa;

public class TulipaStepStatus
{
    public static final int PRODUCTIVE = 1;
    public static final int UNPRODUCTIVE = 2;
    public static final int PREVENTED_PRODUCTION = 3;
}
