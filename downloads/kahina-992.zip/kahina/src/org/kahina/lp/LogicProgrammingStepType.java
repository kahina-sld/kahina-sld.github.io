package org.kahina.lp;

public class LogicProgrammingStepType
{
    public static final int CALL = 0;
    public static final int EXIT = 1;
    public static final int DET_EXIT = 2;
    public static final int FAIL = 3;
    public static final int REDO = 4;
	public static final int PSEUDO_BLOCKED = 5;
	public static final int PSEUDO_UNBLOCKED = 6;
    public static final int EXCEPTION = 7;
}
