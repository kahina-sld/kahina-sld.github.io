package org.kahina.tralesld.data.chart;

public class TraleSLDChartEdgeStatus
{
    public static final int FAILED = 0;
    public static final int SUCCESSFUL = 1;
    public static final int PROSPECTIVE = 2;
}
