package org.kahina.tralesld;

import org.kahina.lp.LogicProgrammingStepType;

public class TraleSLDStepType extends LogicProgrammingStepType
{
    public static final int RULE_APPLICATION = 8;
    public static final int FINISHED = 9;
}
