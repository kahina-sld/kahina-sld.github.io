package org.kahina.tralesld;

public class TraleSLDStepStatus
{
    public static final int PROGRESS = 0;
}
