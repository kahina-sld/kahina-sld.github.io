package org.kahina.tralesld.control.event;

public class TraleSLDBridgeEventType
{
    public static final int RULE_APP = 0;
    public static final int STEP_FINISHED = 2;
}
