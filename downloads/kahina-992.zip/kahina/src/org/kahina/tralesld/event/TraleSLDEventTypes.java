package org.kahina.tralesld.event;

import org.kahina.core.event.KahinaEventTypes;

public interface TraleSLDEventTypes extends KahinaEventTypes
{
	public static final String FS_EDITOR_MESSAGE = "editor message";
	public static final String TYPE_SELECTION = "type selection";
}
