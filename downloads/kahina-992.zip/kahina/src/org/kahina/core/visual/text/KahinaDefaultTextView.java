package org.kahina.core.visual.text;

import org.kahina.core.control.KahinaController;
import org.kahina.core.data.text.KahinaLineReference;

public class KahinaDefaultTextView extends KahinaTextView<KahinaLineReference>
{

	public KahinaDefaultTextView(KahinaController control)
	{
		super(control);
	}
    
}
