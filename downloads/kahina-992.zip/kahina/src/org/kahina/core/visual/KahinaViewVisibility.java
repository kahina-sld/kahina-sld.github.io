package org.kahina.core.visual;

public class KahinaViewVisibility
{   
    public static final int INVISIBLE = 0;
    public static final int EMBEDDED = 1;  
    public static final int FREE = 2;
}
