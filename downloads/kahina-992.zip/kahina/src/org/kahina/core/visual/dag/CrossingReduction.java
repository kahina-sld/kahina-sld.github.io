package org.kahina.core.visual.dag;

import java.util.ArrayList;
import java.util.List;

import org.kahina.core.data.dag.KahinaDAG;

public class CrossingReduction 
{
	public static ArrayList<List<Integer>> minimizeCrossings(KahinaDAG dag, ArrayList<List<Integer>> preliminaryNodeLevels)
	{
		return preliminaryNodeLevels;
	}
}
