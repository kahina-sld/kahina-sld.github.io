package org.kahina.core;

import org.kahina.core.data.KahinaObject;

public class KahinaStep extends KahinaObject
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 7289160962407655124L;

	public KahinaStep()
    {
    }
}
