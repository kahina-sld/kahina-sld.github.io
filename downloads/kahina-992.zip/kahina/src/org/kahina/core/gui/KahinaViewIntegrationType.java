package org.kahina.core.gui;

public class KahinaViewIntegrationType
{
    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1;
    public static final int TABBED = 2;
}
