package org.kahina.core.gui;

public class KahinaWindowType 
{
	public static final int DEFAULT_WINDOW = 0;
	public static final int HORI_SPLIT_WINDOW = 1;
	public static final int VERT_SPLIT_WINDOW = 2;
	public static final int TABBED_WINDOW = 3;
	public static final int LIST_WINDOW = 4;
	public static final int MAIN_WINDOW = 5;
	public static final int CONTROL_WINDOW = 6;
}
