package org.kahina.core.gui.event;

import org.kahina.core.event.KahinaEvent;

public class KahinaRedrawEvent extends KahinaEvent
{
    public KahinaRedrawEvent()
    {
        super("redraw");
    }
}
