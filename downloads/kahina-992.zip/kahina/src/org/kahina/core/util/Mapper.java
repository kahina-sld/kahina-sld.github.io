package org.kahina.core.util;

public interface Mapper<F, T>
{
	
	public T map(F x);

}
