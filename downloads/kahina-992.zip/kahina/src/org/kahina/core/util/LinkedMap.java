package org.kahina.core.util;

/**
 * Map implementation based on linked lists geared towards small collections,
 * designed to be space-efficient.
 * 
 * @author ke
 * 
 */
public class LinkedMap
{

}
