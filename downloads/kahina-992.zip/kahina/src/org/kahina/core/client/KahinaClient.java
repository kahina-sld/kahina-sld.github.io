package org.kahina.core.client;

public class KahinaClient
{
    
}
