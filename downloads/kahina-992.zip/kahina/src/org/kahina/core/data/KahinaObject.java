package org.kahina.core.data;

import java.io.Serializable;

public class KahinaObject implements Serializable
{

	private static final long serialVersionUID = -262730875988653793L;
}
