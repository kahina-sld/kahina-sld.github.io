package org.kahina.core.data.tree;

public class DefaultLayerDecider extends LayerDecider
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4016640936973844302L;

	@Override
	public int decideOnLayer(int nodeID, KahinaTree tree)
	{
		return 0;
	}
}
