package org.kahina.core.event;

public class KahinaTreeEventType
{
    public static final int NEW_NODE = 0;
	public static final int LAYER = 1;
}
