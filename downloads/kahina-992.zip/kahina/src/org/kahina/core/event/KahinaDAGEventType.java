package org.kahina.core.event;

public class KahinaDAGEventType
{
    public static final int NEW_NODE = 0;
}
