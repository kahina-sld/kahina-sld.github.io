:- use_module(kahinaswi).
:- ['examples/example'].
:- trace.
:- main.
