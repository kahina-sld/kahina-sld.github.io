package org.kahina.tralesld;

import org.junit.Test;

public class TraleSLDTest
{
	
	@Test
	public void test1()
	{
		new TraleSLDInstance();
	}

}
